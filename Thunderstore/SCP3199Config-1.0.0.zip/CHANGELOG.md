### 1.0.0 ###
This mod makes it so you can configure the spawn rate of SCP1399 which has no config as of yet. This mod will be deprecated once SCP1399 releases a config.